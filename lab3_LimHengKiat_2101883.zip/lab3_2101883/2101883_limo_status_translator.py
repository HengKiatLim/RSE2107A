#!/usr/bin/env python
 
from __future__ import print_function
 
from limo_base.msg import LimoStatus,AddTwoIntsResponse
import rospy
 
def handle_add_two_ints(req):
     print("Returning [%s + %s = %s]"%(req.a, req.b, (req.a + req.b)))
     return AddTwoIntsResponse(req.a + req.b)

     print("Vehicle state [%s]"%(req.vehicle_state))
     print("Control mode [%s]"%(req.control_mode))
     print("battery voltage [%s]"%(req.battery_voltage))
     print("error code [%s]"%(req.error_code))
     print("motion mode [%s]"%(req.motion_mode))
 
def add_two_ints_server():
     rospy.init_node('limo_status_translator')
     s = rospy.Service('limo_status',LimoStatus, handle_add_two_ints)
     print("Server Ready")
     rospy.spin()
 
if __name__ == "__main__":
       add_two_ints_server()
